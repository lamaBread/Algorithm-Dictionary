<h2>std::max_element</h2>
<?php
printCode(<<<E
int maxElement = *max_element(arr.begin(), arr.end());
E)
?>
<ul>
    <li>반환: 범위에서 가장 큰 원소의 반복자.</li>
    <li>매개변수: 반복자 범위 시작 - 끝</li>
    <li>소속: algorithm 헤더</li>
    <li>시간복잡도: O(n) (완전탐색)</li>
</ul>