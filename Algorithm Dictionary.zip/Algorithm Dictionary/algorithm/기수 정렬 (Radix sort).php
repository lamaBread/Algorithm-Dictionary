<h2>기수 정렬</h2>
<p>특수한 조건을 만족하는 데이터에 대해서는, 기수 정렬을 할 수 있다.</p>
<p>기수 정렬이란, 분배 기반 정렬 알고리즘의 일종이다. 수의 각 자릿수를 주소로 삼아서, 전체 데이터를 분배하여 정렬을 마친다.</p>
<p>가장 간단하게 구현하는 방법은, 10개의 큐를 선언하여, 가장 작은 자릿수부터 가장 큰 자릿수까지를 반복적으로 인덱스로 삼아 큐에 다시 집어넣기를 반복하는 것이다.</p>

<h4>특징</h4>
<ul>
    <li>안정 정렬이다. (큐로 만든 버킷 내부에서 순서 변동 불가)</li>
    <li>d 자리수 데이터에 대하여, O(dn) 시간이 소요된다. ([넣는데 n, 빼는데 n 소요] * 자릿수만큼 반복)</li>
    <li>공간복잡도가 O(n)이다. (n개의 원소가 저장된 가변길이 큐 10개)</li>
</ul>
<p></p>
<p></p>

<h4>Code</h4>
<p>길게 설명할 이유가 없다. 다음 코드를 보라.</p>
<?php
printCode(<<<E
#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

// 기수 정렬을 하나의 함수로 구현 (버킷을 큐로 사용)
void radixSort(std::vector<int>& arr) {
    if (arr.empty()) return;

    // 최대값을 찾고, 최대 자릿수를 계산
    int maxElement = *std::max_element(arr.begin(), arr.end());
    int divisor = 1; // 나눗셈 연산을 위한 초기값 (1의 자리부터 시작)

    // 10개의 큐를 버킷으로 사용
    std::vector<std::queue<int>> buckets(10);

    while (maxElement / divisor > 0) {
        // 각 숫자를 적절한 버킷(큐)에 삽입
        for (int num : arr) {
            int digit = (num / divisor) % 10;
            buckets[digit].push(num);
        }

        // 버킷에서 숫자를 꺼내어 원본 배열 재구성
        int index = 0;
        for (int i = 0; i < 10; i++) {
            while (!buckets[i].empty()) {
                arr[index++] = buckets[i].front();
                buckets[i].pop();
            }
        }

        // 다음 자릿수로 이동
        divisor *= 10;
    }
}

int main() {
    std::vector<int> arr = {170, 45, 75, 90, 802, 24, 2, 66};

    std::cout << "Original array: ";
    for (int num : arr) {
        std::cout << num << " ";
    }
    std::cout << std::endl;

    radixSort(arr);

    std::cout << "Sorted array: ";
    for (int num : arr) {
        std::cout << num << " ";
    }
    std::cout << std::endl;

    return 0;
}

E);