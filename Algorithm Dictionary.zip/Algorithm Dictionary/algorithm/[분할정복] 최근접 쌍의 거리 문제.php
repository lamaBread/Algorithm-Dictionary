<h2>최근접 쌍의 거리 문제</h2>
<p>좌표평면에서 가장 가까운 두 점을 구하는 문제이다.</p>
<p>억지 기법으로 해결한다면, 모든 두 점의 조합을 다 검사해야 하므로, O(n<sup>2</sup>) 시간이 소요된다.</p>
<p>그러나 적절한 방법으로 더 빨리 구할 수 있다.</p>

<h4>알고리즘 개요</h4>
<ol>
    <li>분할: x좌표를 기준으로 하여, 점이 저장된 배열을 둘로 나눈다. (x좌표 기준으로 정렬된 상태로 시작)</li>
    <li>정복: 분할된 하나의 영역에 점이 3개 이하가 될 때 까지 1번 항목을 반복한다. 점의 개수가 3개 이하가 되었다면, 현재 범위에서 최근접 쌍을 계산한다.</li>
    <li>병합: 분할된 각 영역을 병합한다. 병합 과정에서 더 작은 최근접 거리를 남기기를 반복한다. 이때 두 영역에 걸친 쌍의 거리(d<sub>cross</sub>)를 계산하여, 왼쪽 영역 내부의 최근접 거리(d<sub>left</sub>)와, 오른쪽 영역 내부의 최근접 거리(d<sub>right</sub>)를 포함하여, 최근접 쌍의 거리를 구해야 한다.</li>
</ol>

<h4>두 영역에 걸친 최근접 거리(d<sub>cross</sub>) 계산</h4>
<p>왼쪽 영역에서 d<sub>left</sub>, 오른쪽 영역에서 d<sub>right</sub>를 구한 바 있다. 이중 더 작은 값을 d 라고 하자.</p>
<p>이때 이 d값이, d<sub>cross</sub>의 후보를 결정한다. 이 부분은 그림으로 보는 것이 더 좋다. 교재('파이썬 알고리즘' - 최영규)의 그림을 인용하겠다.</p>
<blockquote>
    <img src="/imgs/최근접 쌍의 거리 문제-1.bmp" alt="">
</blockquote>
<p>위 그림에 있는 2d 폭의 띠 영역 내부에 있는 점들에 대해서만 d<sub>cross</sub>를 계산하면 된다.</p>
<p>하지만 연산 범위가 2d 폭의 띠 영역으로 좁혀졌다고 해도, 최악의 경우를 고려하면 여전히 O(n<sup>2</sup>)시간이 소요된다. 이때 y좌표를 기준으로 정렬하여, y좌표의 차이가 d보다 작은 쌍의 경우만 거리를 계산하면 된다. (y값의 간격이 d를 넘으면, d<sub>cross</sub>가 될 수 없다.)</p>
<p>최종적으로 전체 연산의 시간 복잡도는 O(nlog<sub>2</sub>n)으로 증명되어 있다.</p>

<h4>Code</h4>
<p>AI에게 부탁하여 코드를 뽑아 보았다.</p>
<?php
printCode(<<<EOD
#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

struct Point {
    double x, y;
};

// 거리 계산 함수
double distance(const Point& p1, const Point& p2) {
    return std::sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y));
}

// x 좌표 기준 정렬
bool compareX(const Point& p1, const Point& p2) {
    return p1.x < p2.x;
}

// y 좌표 기준 정렬
bool compareY(const Point& p1, const Point& p2) {
    return p1.y < p2.y;
}

// 분할 정복 알고리즘으로 최근접 거리 찾기
double closestPairUtil(std::vector<Point>& points, int left, int right) {
    if (right - left <= 3) { // 점의 개수가 3개 이하일 경우 브루트 포스
        double minDist = INFINITY;
        for (int i = left; i < right; ++i) {
            for (int j = i + 1; j < right; ++j) {
                minDist = std::min(minDist, distance(points[i], points[j]));
            }
        }
        return minDist;
    }

    int mid = left + (right - left) / 2;
    double midX = points[mid].x;

    double leftMin = closestPairUtil(points, left, mid);
    double rightMin = closestPairUtil(points, mid, right);

    double minDist = std::min(leftMin, rightMin);

    // 중간 영역에서 가까운 점 확인
    std::vector<Point> strip;
    for (int i = left; i < right; ++i) {
        if (std::fabs(points[i].x - midX) < minDist) {
            strip.push_back(points[i]);
        }
    }

    std::sort(strip.begin(), strip.end(), compareY);

    for (size_t i = 0; i < strip.size(); ++i) {
        for (size_t j = i + 1; j < strip.size() && (strip[j].y - strip[i].y) < minDist; ++j) {
            minDist = std::min(minDist, distance(strip[i], strip[j]));
        }
    }

    return minDist;
}

// 최근접 쌍 거리 찾기 함수
double closestPair(std::vector<Point>& points) {
    std::sort(points.begin(), points.end(), compareX);
    return closestPairUtil(points, 0, points.size());
}

int main() {
    std::vector<Point> points = {{2.1, 3.1}, {5.4, 2.3}, {1.5, 1.9}, {4.7, 4.1}, {3.3, 3.0}};

    double result = closestPair(points);
    std::cout << "The smallest distance is: " << result << std::endl;

    return 0;
}

EOD);
?>

<p>설명한 그대로의 구현이다... 더 이상의 설명은 의미가 없는 것 같다.</p>