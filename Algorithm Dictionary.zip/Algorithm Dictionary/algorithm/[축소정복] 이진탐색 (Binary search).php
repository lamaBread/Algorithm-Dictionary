<h2>이진탐색 (Binary search)</h2>
<p>이진탐색의 원리는 이미 알고 있을 것이다. 정렬이 된 컨테이너에 대하여, [현재 범위의 중간 탐색 -> 왼쪽과 오른쪽 중 한쪽을 버린다]를 반복하는 것이다.</p>
<p>일단 std::binary_search, std::lower_bound, std::upper_bound 의 사용법을 먼저 보자. (모두 std::algorithm 에 속함.)</p>
<?php
printCode('std::vector<int> vec = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
int value = 5;

if (std::binary_search(vec.begin(), vec.end(), value)) {
    std::cout << "Value found." << std::endl;
} else {
    std::cout << "Value not found." << std::endl;
}');
?>
<p>값을 찾았다면 true, 찾지 못했다면 false를 반환한다.</p>
<br>
<?php
printCode(<<<EOD
// 특정 값보다 크거나 같은 첫 번째 원소의 이터레이터를 반환.
auto it = std::lower_bound(vec.begin(), vec.end(), value);

// 특정 값보다 큰 첫 번째 원소의 이터레이터를 반환.
auto it = std::upper_bound(vec.begin(), vec.end(), value);
EOD);
?>
<p>간단하지 않은가? 일반적으로 std::lower_bound를 가장 많이 사용한다는 점을 기억하자. <br><small>(있다 없다를 반환하는 std::binary_search의 기능이 별 쓸모가 없으며 특별히 더 빠르지 않고, std::upper_bound의 경우도 필요한 경우가 거의 없다.)</small></p>
<hr>
<p>AI에게 구현을 요구하면 다음과 같다.</p>
<?php
printCode(<<<EOD
template <typename T>
int binarySearch(const std::vector<T>& arr, T key) {
    int low = 0;
    int high = arr.size() - 1;

    while (low <= high) {
        int mid = low + (high - low) / 2;
        
        if (arr[mid] == key)
            return mid;
        else if (arr[mid] < key)
            low = mid + 1;
        else
            high = mid - 1;
    }

    return -1; // 키를 찾지 못한 경우
}
EOD);
?>
<p>이터레이터 기반으로 정의되지 않은 점이 마음에 들지 않지만, 얼핏 보기에 정상적인 코드가 맞아 보인다. 잘 작동하기도 했다.</p>

<hr>
<p>시간복잡도는 O(log<sub>2</sub>n)이다.</p>