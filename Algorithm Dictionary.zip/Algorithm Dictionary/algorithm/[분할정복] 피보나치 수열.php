<h2>[분할정복] 피보나치 수열</h2>
<p>많은 문제가 분할했을 때, 전체 크기가 줄어들거나 그대로이다. 그러나 어떤 경우에는 문제가 더 커질 수 있다. 피보나치 수열이 대표적인 예시이다.</p>
<p>그러나 피보나치 수열은 구해야 하는 부분 문제가 중복되는 것이 문제이므로, 다양한 방법으로 개선할 수 있다.</p>
<p>다음 코드를 보라.</p>
<?php
printCode(<<<EOD
#include <iostream>
#include <vector>
#include <chrono>

// 순환 호출 O(2^n)
int fibonacci1(int n) {
    if (n == 0 || n == 1) return n;
    return fibonacci1(n - 1) + fibonacci1(n - 2);
}

// 반복 O(n)
int fibonacci2(int n) {
    if (n == 0 || n == 1) return n;
    int f1 = 0, f2 = 1, r = 0;
    for (int i = 2; i <= n; ++i) {
        r = f1 + f2;
        f1 = f2;
        f2 = r;
    }
    return r;
}

// 메모이제이션 사용 O(n)
std::vector<int> mem(500, -1);
int fibonacci3(int n) {
    if (mem[n] != -1) return mem[n];
    if (n == 0 || n == 1) return n;
    mem[n] = fibonacci3(n - 1) + fibonacci3(n - 2);
    return mem[n];
}

// 행렬의 거듭제곱을 이용한 행렬 곱셈 O(logn)
using Matrix = std::vector<std::vector<int>>;

Matrix matrix_mul(const Matrix& A, const Matrix& B) {
    return {
        {A[0][0] * B[0][0] + A[0][1] * B[1][0], A[0][0] * B[0][1] + A[0][1] * B[1][1]},
        {A[1][0] * B[0][0] + A[1][1] * B[1][0], A[1][0] * B[0][1] + A[1][1] * B[1][1]}
    };
}

Matrix matrix_power_recur(const Matrix& mat, int n) {
    if (n == 0) return {{1, 0}, {0, 1}}; // Identity matrix
    if (n == 1) return mat;

    Matrix result = matrix_power_recur(matrix_mul(mat, mat), n / 2);
    if (n % 2 == 1) {
        result = matrix_mul(result, mat);
    }
    return result;
}

int fibonacci5(int n) {
    if (n == 0 || n == 1) return n;
    Matrix fib_matrix = {{1, 1}, {1, 0}};
    Matrix result_matrix = matrix_power_recur(fib_matrix, n - 1);
    return result_matrix[0][0];
}
EOD)
?>

<p>내 생각에는, 메모이제이션만 잘 기억해 두어도 좋을 것 같다. 우리가 익히 알고 있는 피보나치 수열의 순환 관계식을 기반으로, 각 값을 배열에 저장하고, 배열에 없는 경우에만 재귀호출 하는 코드. (fibonacci3())</p>