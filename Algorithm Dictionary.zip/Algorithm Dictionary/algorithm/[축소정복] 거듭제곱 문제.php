<h2>거듭제곱 문제</h2>
<p>거듭제곱을 다음과 같이 억지 기법으로 계산할 수 있다.</p>
<?php
printCode(<<<EOD
template <typename T>
T power(T x, unsigned n){
    T result = (T)1;
    for(unsigned i=0; i<n; i++){
        result *= x;
    }
    return result;
}
EOD);
?>
<p>위와 같이 계산해도 O(n)시간이므로, 사실 큰 문제는 없다. <br>하지만 시간을 더 단축할 수 있다.</p>
<?php
printCode(<<<EOD
template <typename T>
T power_2(T x, unsigned n){
    if(n==0){
        return 1;  //탈출조건.
    }else if(n%2 == 0){
        return power_2(x*x, n/2);  //짝수번 제곱인 경우.
    }else{
        return x * power_2(x*x, n/2);  //홀수번 제곱인 경우.
    }
}
EOD);
?>
<p>놀랍지 않은가? 문제의 크기가 절반씩 축소되므로, O(log<sub>2</sub>n)시간 정도로 빨라졌다.</p>