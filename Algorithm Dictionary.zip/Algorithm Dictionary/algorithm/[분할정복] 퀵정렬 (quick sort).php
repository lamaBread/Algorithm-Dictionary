<h2>퀵 정렬 (Quick sort)</h2>
<p>병합정렬이 배열의 크기(길이, 위치)를 기준으로 분할했다면, 퀵 정렬은 피벗의 값이 분할의 기준이다.</p>
<p>알고리즘을 설명하자면 다음과 같다.</p>
<ol>
    <li>피벗(pivot) 선택. (일반적으로 배열의 첫 원소)</li>
    <li>피벗을 기준으로 분할(partition)연산 수행. (일반적으로 피벗보다 작은 값이 왼쪽, 큰 값은 오른쪽)</li>
    <li>분할된 두 배열 각각에 대하여 과정 1, 2를 반복적으로 수행. (더 이상 분할할 수 없을 때 까지)</li>
</ol>

<h4>Code</h4>
<p>파티션 연산은 일단 무시하고, 퀵 정렬의 코드를 먼저 보라.</p>
<?php
printCode(<<<EOD
template <typename T>
void quick_sort(std::vector<T>::iterator begin, std::vector<T>::iterator last)
{
	// 만약 벡터에 하나 이상의 원소가 있다면
	if (std::distance(begin, last) >= 1)
	{
		// 분할 작업을 수행
		auto partition_iter = partition<T>(begin, last);

		// 분할 작업에 의해 생성된 벡터를 재귀적으로 정렬
		quick_sort<T>(begin, partition_iter - 1);
		quick_sort<T>(partition_iter, last);
	}
}
EOD);
?>
<p>분할이 가능하다면, 분할된 배열에 대하여 또 다시 정렬 함수를 호출한다.</p>
<p>이때 partition 함수는 std::partition 이 이미 존재한다.</p>
<?php
printCode(<<<EOD
//std::partition
template<class ForwardIterator, class UnaryPredicate>
ForwardIterator partition(ForwardIterator first, ForwardIterator last, UnaryPredicate p);
EOD);
?>
<ul>
    <li>first: 처리할 범위의 시작 반복자.</li>
    <li>last: 처리할 범위의 끝 반복자 (범위는 [first, last). last를 포함하지 않는다.).</li>
    <li>p: 조건을 나타내는 단항 함수 객체(람다 함수 가능). 반환값이 true인 요소가 앞쪽으로 이동.</li>
    <li>반환: 조건을 만족하는 그룹의 마지막 다음 주소. (조건을 불만족하는 그룹의 첫 원소 주소)</li>
</ul>

<p>partition 연산의 동작 과정은 다음과 같다.</p>

<?php
printCode(<<<EOD
//'코딩테스트를 위한 알고리즘 with C++' 수록 코드.
template <typename T>
auto partition(typename std::vector<T>::iterator begin,
	typename std::vector<T>::iterator end)
{
	auto pivot_val = *begin;
	auto left_iter = begin + 1;
	auto right_iter = end;

	while (true)
	{
		// 벡터의 첫 번째 원소부터 시작하여 피벗보다 큰 원소를 찾습니다.
		while (*left_iter <= pivot_val && std::distance(left_iter, right_iter) > 0)
			left_iter++;

		// 벡터의 마지막 원소부터 시작하여 역순으로 피벗보다 작은 원소를 찾습니다.
		while (*right_iter > pivot_val && std::distance(left_iter, right_iter) > 0)
			right_iter--;

		// 만약 left_iter와 right_iter가 같다면 교환할 원소가 없음을 의미합니다.
		// 그렇지 않으면 left_iter와 right_iter가 가리키는 원소를 서로 교환합니다.
		if (left_iter == right_iter)
			break;
		else
			std::iter_swap(left_iter, right_iter);
	}

	if (pivot_val > *right_iter)
		std::iter_swap(begin, right_iter);

	return right_iter;
}
EOD);
?>
<p>두 반복자 각각을 while문으로 올바른 위치(교환이 필요한 원소)까지 전진시키는 것에 주목하라. 바깥 while문이 1회 돌 때 마다, 내부의 while문이 찾아낸 교환 대상인 두 원소가 교환(std::swap)된다.</p>

<h4>특징</h4>
<ul>
    <li>partition 연산이 원소를 반복적으로 교환하므로, 불안정 정렬이다.</li>
    <li>피벗 값에 따라서 정렬 소요시간이 크게 달라진다. => 피벗 값을 잘 선택하기 위한 다양한 방법이 제시되어 있음. 중간값 선택 등.</li>
    <li>일반적인 경우 1.39nlog<sub>2</sub>n 의 시간이 소요된다고 알려져 있다.</li>
</ul>

<h4>시간복잡도</h4>
<p>순환관계식은 병합정렬과 동일하다. 그러나 partition 연산에서 먼 거리의 원소를 '교환'하는 방식으로 계산된다는 점과, 피벗이 연산에서 제외된다는 점으로 인하여, 병합정렬보다 빠르게 동작한다고 알려져 있다.</p>
<p>최선의 경우: O(nlog<sub>2</sub>n) &emsp; (정확히 반으로 계속하여 분할된 경우)</p>
<p>최악의 경우: O(n<sup>2</sup>) &emsp; (피벗이 전체 배열에서 가장 작거나 큰 원소로 계속 선택된 경우)</p>
