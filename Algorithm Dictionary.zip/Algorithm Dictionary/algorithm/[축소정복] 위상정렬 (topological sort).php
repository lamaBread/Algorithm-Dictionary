<h2>위상정렬 (topological sort)</h2>
<p>방향 그래프의 모든 원소를 순회할 수 있는 순서를 구하는 것을 '위상정렬'이라 한다.<br>(각 정점들의 선행 순서를 위반하지 않아야 한다.)</p>
<p>위상정렬을 억지기법으로 풀 수 있다. 진입차수가 0인 정점을 우선하여 DFS를 반복적으로 수행하면 위상정렬이 완료된다.</p>
<p>하지만 축소정복 기법으로 위상정렬을 수행할 수도 있다. (DFS에서 방문노드를 기록하는 것과 달리, 특정 노드를 없애어 축소정복으로 푼다는 의미)</p>
<?php
$code = <<<EOD
#include <iostream>
#include <vector>
#include <map>
#include <queue>
#include <string>

// 위상 정렬 함수 (제네릭 타입 사용)
template <typename T>
std::vector<T> topologicalSort(const std::map<T, std::vector<T>>& graph) {
    // 진입 차수 저장을 위한 맵
    std::map<T, int> inDegree;
    for (const auto& node : graph) {
        const T& u = node.first;
        // 모든 노드 초기화
        if (inDegree.find(u) == inDegree.end()) {
            inDegree[u] = 0;
        }
        // 각 노드의 진입 차수 계산
        for (const T& v : node.second) {
            inDegree[v]++;
        }
    }

    // 진입 차수가 0인 노드를 위한 큐
    std::queue<T> q;
    for (const auto& node : inDegree) {
        if (node.second == 0) {
            q.push(node.first);
        }
    }

    // 위상 정렬 결과를 저장할 벡터
    std::vector<T> topOrder;

    // Kahn's Algorithm 수행
    while (!q.empty()) {
        T u = q.front();
        q.pop();
        topOrder.push_back(u);

        // 인접 노드의 진입 차수 감소
        if (graph.find(u) != graph.end()) {
            for (const T& v : graph.at(u)) {
                inDegree[v]--;
                if (inDegree[v] == 0) {
                    q.push(v);
                }
            }
        }
    }

    // 그래프에 사이클이 있는 경우 (위상 정렬이 불가능한 경우)
    if (topOrder.size() != inDegree.size()) {
        std::cerr << "Cycle detected! Topological sort is not possible." << std::endl;
        return {};
    }

    return topOrder;
}

// 테스트 함수
int main() {
    // 방향 그래프 생성 (string 타입 사용)
    std::map<std::string, std::vector<std::string>> graph = {
        {"A", {"B", "C"}},
        {"B", {"D"}},
        {"C", {"D"}},
        {"D", {"E"}},
        {"E", {}}
    };

    // 위상 정렬 수행
    std::vector<std::string> result = topologicalSort(graph);

    // 결과 출력
    if (!result.empty()) {
        std::cout << "Topological Sort: ";
        for (const std::string& node : result) {
            std::cout << node << " ";
        }
        std::cout << std::endl;
    }

    return 0;
}
EOD;
printCode($code);
?>

<p>중요한 것은, O(n+e) 시간이 소요된다는 점이다. 구체적으로는 다음과 같다.</p>
<ul>
    <li>첫 번째 for(12행): 모든 노드(n개) 초기화 수행
        <ol><li>내부 for문에서 모든 인접노드(최대 e개)에 접근하여 진입차수 증가</li></ol>
    </li>
    <li>두 번째 for(26행): 모든 노드(n개)를 순회하여 진입차수가 0인 노드를 큐에 삽입</li>
    <li>36행 while: 큐가 빌 때 까지
        <ol>
            <li>진입차수가 0인 노드를 큐에서 꺼내어, 모든 인접노드(최대 e개)를 순회하며 진입차수 감소</li>
        </ol>
    </li>
</ul>

<p>요약하자면, 2(n+e) 시간이 소요되므로 O(n+e) 시간이 걸린다는 의미이다.</p>
<p>[진입차수가 0인 노드 삭제 -> 모든 인접노드의 진입차수 수정]을 반복하는 것이 전부이다.</p>