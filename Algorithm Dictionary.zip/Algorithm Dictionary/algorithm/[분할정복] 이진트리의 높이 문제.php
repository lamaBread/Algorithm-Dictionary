<h2>이진트리의 높이 문제</h2>
<p>이진트리의 높이를 구하는데 걸리는 시간은 어떠한 방법을 써도 O(n) 시간이 소요된다. 결국 모든 노드를 방문해 보아야 하기 때문이다.</p>

<h4>시간복잡도</h4>
<p>포화이진트리가 있다고 가정하자. 양측의 노드 개수는 같은 경우, 분할정복을 수행하는 순환관계식은 다음과 같다.</p>
<p>T(n) = T(n<sub>left</sub>) + T(n<sub>right</sub>) + 1</p>
<p>양측의 노드 개수가 같으므로 위의 식은 다음과 같다.</p>
<p>T(n) = 2T(n/2) + 1</p>
<p>그러므로 O(n) 시간이 소요된다.</p>

<h4>순회</h4>
<p>전위, 중위, 후위 순회의 구현은 간단하다. 재귀호출 과정에서 어느 순서로 출력하느냐만 잘 정하면 된다.</p>
<p>1차원 배열로 구현된 이진 트리가 있다고 하자. 이때 전, 중, 후위순회 함수는 다음과 같이 작성된다.</p>

<?php
printCode(<<<EOD
using namespace std;

void pre_order(int now, vector<char>& tree){ 
	if(now < tree.size() && tree[now] != '\0'){
		cout << tree[now];
		pre_order(now*2, tree);
		pre_order(now*2+1, tree);
	}
	return;
} 

void in_order(int now, vector<char>& tree){
	if(now < tree.size() && tree[now] != '\0'){
		in_order(now*2, tree);		
		cout << tree[now];
		in_order(now*2+1, tree);
	}
	return;
}

void post_order(int now, vector<char>& tree){
	if(now < tree.size() && tree[now] != '\0'){
		post_order(now*2, tree);
		post_order(now*2+1, tree);
		cout << tree[now];
	}
	return;
}
EOD);
?>
<p>더 이상의 설명은 생략하겠다.</p>