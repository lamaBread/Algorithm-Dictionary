<h2>[동적 계획법]이항계수 구하기</h2>
<p>파스칼의 삼각형을 잘 보면, 이항계수가 순환관계식으로 정의됨을 알 수 있다.</p>
<blockquote>
    <img src="/imgs/이항계수 순환관계식.bmp" alt="">
</blockquote>

<p>아마 이 시점에서 모든 사항을 이해했을 것이다. 피보나치 수열에서 재귀적으로 메모이제이션 기법을, 반복적으로 테이블화 기법을 사용했던 것 처럼, 이항계수도 똑같이 구할 수 있다.</p>
<p>다만 k와 n을 모두 저장해야 하므로, 2차원 배열을 사용하여 메모이제이션/테이블화를 수행해야 한다.</p>

<h4>Code</h4>
<?php
printCode(<<<E
#include <iostream>
#include <vector>

// 메모이제이션을 사용한 이항계수 계산 함수
template<typename T>
T binomial_memoization(int n, int k, std::vector<std::vector<T>> &memo) {
    if (k == 0 || k == n) {
        return 1; // nC0 = nCn = 1
    }
    if (memo[n][k] != -1) {
        return memo[n][k];
    }
    memo[n][k] = binomial_memoization(n - 1, k - 1, memo) + binomial_memoization(n - 1, k, memo);
    return memo[n][k];
}

// 테이블화를 사용한 이항계수 계산 함수
template<typename T>
T binomial_tabulation(int n, int k) {
    std::vector<std::vector<T>> dp(n + 1, std::vector<T>(k + 1, 0));

    for (int i = 0; i <= n; ++i) {
        for (int j = 0; j <= std::min(i, k); ++j) {
            if (j == 0 || j == i) {
                dp[i][j] = 1; // nC0 = nCn = 1
            } else {
                dp[i][j] = dp[i - 1][j - 1] + dp[i - 1][j];
            }
        }
    }

    return dp[n][k];
}

int main() {
    int n, k;
    std::cout << "Enter n and k for nCk: ";
    std::cin >> n >> k;

    // 메모이제이션 실행
    std::vector<std::vector<long long>> memo(n + 1, std::vector<long long>(k + 1, -1));
    std::cout << "Binomial Coefficient (Memoization): " << binomial_memoization<long long>(n, k, memo) << std::endl;

    // 테이블화 실행
    std::cout << "Binomial Coefficient (Tabulation): " << binomial_tabulation<long long>(n, k) << std::endl;

    return 0;
}
E);
?>