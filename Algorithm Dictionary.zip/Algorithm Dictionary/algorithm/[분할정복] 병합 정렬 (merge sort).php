<h2>병합 정렬 (merge sort)</h2>
<p>대표적인 분할정복 알고리즘이다. (이 교재는 축소정복과 분할정복을 따로 나누어 설명하는데, 최종적으로 컨테이너의 모든 원소를 정복해야 하는 경우만을 분할정복으로 본 것이다.)</p>
<p>알고리즘은 다음과 같이 설명할 수 있다.</p>
<ol>
    <li>입력 배열을 같은 크기인 두 개의 부분 배열로 분할.</li>
    <li>부분 배열의 크기가 충분히 작지 않다면 1번으로 이동. 충분히 작다면 정렬되었다 판단하고 다음으로 이동.<br><small>(충분히 작다 = 크기가 1이다)</small></li>
    <li>정렬된 부분 배열을 병합.</li>
</ol>

<h4>Code</h4>
<p>구체적인 코드는 다음과 같다.</p>
<?php
printCode(<<<EOD
#include <iostream>
#include <vector>

template <typename T>
std::vector<T> merge(std::vector<T>& arr1, std::vector<T>& arr2)
{
	std::vector<T> merged;

	auto iter1 = arr1.begin();
	auto iter2 = arr2.begin();

	while (iter1 != arr1.end() && iter2 != arr2.end())
	{
		if (*iter1 < *iter2)
		{
			merged.emplace_back(*iter1);
			iter1++;
		}
		else
		{
			merged.emplace_back(*iter2);
			iter2++;
		}
	}

	if (iter1 != arr1.end())
	{
		for (; iter1 != arr1.end(); iter1++)
			merged.emplace_back(*iter1);
	}
	else
	{
		for (; iter2 != arr2.end(); iter2++)
			merged.emplace_back(*iter2);
	}

	return merged;
}

template <typename T>
std::vector<T> merge_sort(std::vector<T> arr)
{
	if (arr.size() > 1)
	{
		auto mid = size_t(arr.size() / 2);
		auto left_half = merge_sort<T>(std::vector<T>(arr.begin(),
			arr.begin() + mid));
		auto right_half = merge_sort<T>(std::vector<T>(arr.begin() + mid,
			arr.end()));

		return merge<T>(left_half, right_half);
	}

	return arr;
}
EOD);
?>
<p>'코딩 테스트를 위한 알고리즘 with C++'에 있는 코드이다. 병합 연산을 직접 제네릭으로 구현하였고, 재귀적으로 실행되는 정렬 함수에서 병합 함수를 호출하도록 되어 있다.</p>
<p>참고로 std::merge 또한 존재한다.</p>
<?php
printCode(<<<EOD
template<class InputIt1, class InputIt2, class OutputIt>
OutputIt merge(InputIt1 first1, InputIt1 last1,
               InputIt2 first2, InputIt2 last2,
               OutputIt d_first);
EOD);
?>
<p>이때 각 매개변수의 의미는 다음과 같다.</p>
<ul>
    <li>first1, last1: 첫 번째 정렬된 범위의 시작과 끝 반복자.</li>
    <li>first2, last2: 두 번째 정렬된 범위의 시작과 끝 반복자.</li>
	<li>d_first: 병합된 결과를 저장할 범위의 시작 반복자.</li>
    <li>반환값: 결과 범위의 마지막 반복자.</li>
</ul>

<p>하지만 굳이 병합정렬을 사용할 일이 없고, 정렬 상태를 유지하면서 배열을 병합하는 일이 별로 없기에, 해당 std::merge는 존재만 기억해두면 되겠다.</p>
<p>중요한 것은, merge 연산에서 두 개의 반복자를 전진시키면서 병합된 배열을 생성한다는 점. 그리고, 재귀호출로 모두 분할된 상태부터 병합을 시작할 수 있다는 점이다.</p>

<h4>특징</h4>
<ul>
    <li>안정 알고리즘이다. 두 반복자가 전진하면서 순차적으로 병합된 배열을 생성하므로, 동일 원소에 대한 자리바꾸기가 존재할 수 없다.</li>
    <li>항상 동일한 시간이 소요되는 알고리즘이다. 배열을 전부 분할하고 병합하는 과정에서 시간 소요는 항상 예측 가능하다.</li>
    <li>배열을 병합하는 과정에서 임시 배열을 사용해야 한다는 단점이 있다. (메모리 소모 증가)</li>
</ul>

<h4>순환관계식</h4>
<p>배열의 크기 n을 2의 거듭제곱으로 단순화 하면, 순환관계식은 다음과 같다.</p>
<p>T(n) = 2T(n/2) + T<sub>merge</sub>(n) &emsp; (n > 1, T(1) = 0)</p>
<p>절반 크기로 분할된 문제가 2개 존재하고, 분할 1회에 상응하는 병합 1회가 필요하다.</p>
<p>이때 병합연산은 최대로 오래 걸려도 n-1회 연산으로 완료할 수 있다. (배열의 최대 크기가 n이고, 두 반복자의 이동 끝에 단 하나의 원소가 남을 때 까지 연산되므로 n-1회 이다.)</p>
<p>그러므로 순환관계식은 다음과 같이 쓸 수 있다.</p>
<p>T(n) = 2T(n/2) + n-1</p>

<h4>시간복잡도</h4>
<p>시간복잡도를 마스터 정리로 구해보겠다.</p>
<ol>
    <li><strong>a = b = 2</strong></li>
    <li>T<sub>merge</sub>(n) = n-1회 연산 = O(n)<br>이때 n<sub>1</sub> 이므로, <strong>d = 1</strong></li>
    <li>a 와 b<sup>d</sup>의 값은 각각 2, 2 이므로, 시간복잡도는 O(n<sup>d</sup>logn) 이다.</li>
    <li>O(nlogn)</li>
</ol>