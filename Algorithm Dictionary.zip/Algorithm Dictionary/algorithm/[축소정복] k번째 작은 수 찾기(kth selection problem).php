<h2>K번째 작은 수 찾기</h2>
<p>설마 정렬을 하는 사람은 없으리라 생각한다.</p>
<p>정상적인 방법은, 선택정렬을 k회 수행하는 것이다. 그러면 O(nk)시간으로 해결 가능하다.</p>
<p>그러나 더 빠른 방법이 있다. 퀵 정렬에 사용되는 파티션 연산을 응용하면 된다. 파티션 연산의 결과 중 하나를 버리기를 반복하며, 배열을 반씩 버리다 보면, k번째 인덱스가 피벗인 순간이 온다.</p>
<?php
printCode(<<<EOD
//사실 std::partition() 이 존재하지만 학습을 위해서 사용하지 않았습니다.
unsigned partition(std::vector<unsigned>& data, unsigned left, unsigned right){
    unsigned low = left+1;  //피벗은 건드리지 않는다. (피벗 다음 인덱스를 low에 할당.)
    unsigned high = right;
    unsigned pivot = data[left];
    while(low <= high){
        while(low <= right && data[low] <= pivot){  //상한조건 && 탈출조건
            low++; //pivot보다 큰 값일 나올 때 까지 증가시킴.
        }
        while(high >= left && data[high] > pivot){  //하한조건 && 탈출조건
            high--;  //pivot보다 작거나 같은 값이 나올 때 까지 감소.
        }
        if(low < high){  //역전 == 종료 필요.
            //역전 X == 교환 필요.
            std::swap(data[low], data[high]);
        }
    }
    std::swap(data[left], data[high]);  //left 위치 == 피벗이 있는 위치. high 위치 == 피벗이 가야 할 위치.
    
    return high;  //피벗 인덱스 반환.
}
EOD);
?>
<p>파티션 연산이 '피벗 인덱스'를 반환하는 것을 보라. 중요한 것은, 그 피벗 인덱스가 k와 동일한 순간까지 반복적으로 파티션을 하는 것이다.</p>
<?php
printCode(<<<EOD
unsigned quick_select(std::vector<unsigned>& data, unsigned left, unsigned right, unsigned k) {
    if (left <= right) {
        unsigned pos = partition(data, left, right);
        
        if (pos == k - 1) {  // k번째 작은 수를 찾음
            return data[pos];
        } else if (pos > k - 1) {  // k번째 작은 수가 왼쪽 부분에 있음
            return quick_select(data, left, pos - 1, k);
        } else {  // k번째 작은 수가 오른쪽 부분에 있음
            return quick_select(data, pos + 1, right, k);
        }
    }
    return -1; // 비정상적인 경우에 대한 처리 (사실상 여기에 도달하지 않음)
}

//주의!!! 호출할 때 배열의 right 값은 .size()-1 이다.
//호출 예:
std::cout << quick_select(data, 0, data.size()-1, 2);
EOD);
?>

<p>이때 k는 1부터 시작하므로, 함수 내부적으로는 k-1을 사용하여 pos와 비교한다.</p>
<p>함수는 이진탐색과 유사하게 절반씩 버리기를 반복하여 k번째 작은 수를 찾는다.</p>