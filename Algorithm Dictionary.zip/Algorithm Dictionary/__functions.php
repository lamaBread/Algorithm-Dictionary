<?php
//이 파일에는 절대 스스로 실행되는 코드를 넣지 말것.
//오로지 함수만 정의.

// 배열 내부에서 특정 문자열 검색.
function findKeysContainingString(array $array, string $searchString): array {
    // 검색 문자열이 비어 있으면 빈 배열 반환
    if (trim($searchString) === '') {
        return [];
    }

    // 배열 필터링: 특정 문자열을 대소문자 구분 없이 포함하는 원소만 추출
    $filteredArray = array_filter($array, function($value) use ($searchString) {
        return stripos($value, $searchString) !== false; // 대소문자 구분 없이 검색
    });

    return $filteredArray;
}

//특정 경로에서 모든 파일명 수집.
function getAllFilesInDirectory($directory) {
    $files = [];

    if (!is_dir($directory)) {
        //echo "The provided path is not a directory.";
        return $files;
    }

    // RecursiveDirectoryIterator를 사용하여 디렉터리 내부 탐색
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($directory, FilesystemIterator::SKIP_DOTS)
    );

    foreach ($iterator as $file) {
        if ($file->isFile()) {
            $temp = $file->getFilename();
            $temp = str_replace('.php', '', $temp);
            $files[] = $temp;  // 파일 이름을 배열에 추가.
        }
    }

    sort($files);

    return $files;
}

//코드 하이라이팅 함수.
function highlightCppCode($code, $colors) {
    // 확장된 키워드 목록
    $keywords = [
        'auto', 'break', 'case', 'catch', 'class', 'const', 'constexpr', 
        'continue', 'default', 'delete', 'do', 'else', 'enum', 'explicit', 
        'export', 'extern', 'for', 'friend', 'if', 'inline', 'mutable', 
        'namespace', 'new', 'noexcept', 'operator', 'private', 'protected', 
        'public', 'return', 'static', 'struct', 'switch', 'template', 
        'throw', 'try', 'typedef', 'typeid', 'typename', 'using', 'virtual', 
        'while', 'override', 'final'
    ];

    // 데이터 타입 확장
    $types = [
        'bool', 'char', 'double', 'float', 'int', 'long', 'short', 
        'signed', 'unsigned', 'void', 'wchar_t', 'string', 'size_t', 
        'auto', 'decltype', 'nullptr_t', 'T', 'T1', 'T2', 'T3'
    ];

    // 정규표현식으로 하이라이트
    $code = preg_replace_callback('/(\b(' . implode('|', array_merge($keywords, $types)) . ')\b|\b(std::\w+)\b|#\w+|\/\/[^\r\n]*|\+\+|--|".*?")/m', function($matches) use ($keywords, $types, $colors) {
        $match = $matches[1];
        if (is_array($types) && in_array($match, $types)) {
            return '<span style="color: ' . $colors['types'] . ';">' . $match . '</span>';
        } elseif (is_array($keywords) && in_array($match, $keywords)) {
            return '<span style="color: ' . $colors['keywords'] . '; font-weight: bold;">' . $match . '</span>';
        } elseif (preg_match('/^#\w+$/', $match)) {
            return '<span style="color: ' . $colors['headers'] . ';">' . $match . '</span>';
        } elseif (preg_match('/^\/\/[^\r\n]*$/', $match)) {
            return '<span style="color: ' . $colors['comments'] . ';">' . $match . '</span>';
        } elseif (preg_match('/^".*?"$/', $match)) {
            return '<span style="color: ' . $colors['strings'] . ';">' . $match . '</span>';
        } elseif (preg_match('/^(\+\+|--)$/', $match)) {
            return '<span style="color: ' . $colors['operators'] . ';">' . $match . '</span>';
        }
        return $match;
    }, htmlspecialchars($code));
        
    return $code;
}

function addLineNumbers($highlightedCode) {
    // 코드 줄별로 나누기
    $lines = explode("\n", $highlightedCode);
    $codeWithLineNumbers = '';

    // 최대 행 번호 자릿수 계산 (최대 행 번호 길이)
    $maxLineNumberLength = strlen((string)count($lines));

    foreach ($lines as $lineNumber => $line) {
        // 행 번호와 코드 사이의 탭을 맞추기 위한 공백 수 계산
        $lineNumberStr = str_pad(($lineNumber + 1), $maxLineNumberLength, ' ', STR_PAD_LEFT);

        // 탭 문자 추가 (행 번호 앞에 적절한 공백으로 시작 위치 맞추기)
        $codeWithLineNumbers .= '<span style="color: #888888;">' . $lineNumberStr . '</span>' . "\t" . $line . "\n";
    }

    return $codeWithLineNumbers;
}

function printCode($code) {
    // 색상 설정
    $colors = [
        'keywords' => '#0000FF',  // 파란색 (키워드)
        'types' => '#008000',      // 초록색 (데이터 타입)
        'headers' => '#800080',    // 보라색 (헤더, 매크로)
        'comments' => '#6A6A6A',   // 회색 (주석)
        'strings' => '#A52A2A',    // 갈색 (문자열)
        'operators' => '#FF4500'   // 주황색 (연산자)
    ];

    // 하이라이팅된 코드 얻기
    $highlightedCode = highlightCppCode($code, $colors);

    // 행 번호 추가
    $highlightedCodeWithLineNumbers = addLineNumbers($highlightedCode);
    
    echo '<pre style="background-color: #ededed; color: #000000; font-family: Consolas, "Courier New", monospace; font-size: 14px;">';  // 밝은 배경, 검은색 텍스트
    echo '<code>';
    echo $highlightedCodeWithLineNumbers;
    echo '</code>';
    echo '</pre>';
}
