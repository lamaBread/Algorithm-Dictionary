<?php
if(!defined("CHECK_MAINPAGE")){
    die();
}
?>
<section id='syntax'>
    <h2>Syntax</h2>
    <ol>
        <?php
            $data = getAllFilesInDirectory("./syntax");
            foreach($data as $filePath){
                echo "<li><a href='/?pageS={$filePath}'>{$filePath}</a></li>";
            }
        ?>
    </ol>
</section>
<section id='algorithm'>
    <h2>Algorithm</h2>
    <ol>
        <?php
            $data = getAllFilesInDirectory("./algorithm");
            foreach($data as $filePath){
                echo "<li><a href='/?pageA={$filePath}'>{$filePath}</a></li>";
            }
        ?>
    </ol>
</section>