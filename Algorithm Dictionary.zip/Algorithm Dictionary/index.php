<?php
    include_once './__functions.php';  //필요한 함수들 모두 로드.
?>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/pico-main/css/pico.classless.jade.min.css">
    <style>
        input {
            transform: scale(0.9); /* 크기를 90%로 축소 */
            transform-origin: center; /* 축소 기준점을 가운데로 설정 */
        }
        a{
            text-decoration-line: none;
        }
    </style>
    <title>C++ Dictionary APP</title>
</head>
<body>
    <header>
        <hgroup>
            <h1>C++ Dictionary</h1>
            <p>Syntax and Algorithms based on C++</p>
        </hgroup>
        <nav>
            <ul>
                <li><a href="/">Main</a></li>
                <li><form action="" method="GET"><input type="text" name="search" placeholder="search" style="display: inline-block; width: 70%;"><input type="submit" value="submit" style="display: inline-block; width: 30%"></form></li>
            </ul>
        </nav>
    </header>
    <main>
        <?php
        if(isset($_GET['search'])){  //무언가를 검색한 경우.
            //검색 결과를 이름에 포함하는 문서 찾아서 출력.
            $search_result_A = findKeysContainingString(getAllFilesInDirectory('./algorithm'), $_GET['search']);
            $search_result_S = findKeysContainingString(getAllFilesInDirectory('./syntax'), $_GET['search']);

            echo "<section><h2>Syntax</h2><ul>";
                foreach($search_result_S as $x){
                    echo "<li><a href='/?pageS={$x}'>{$x}</a></li>";
                }
            echo "</ul></section>";

            echo "<section><h2>Algorithm</h2><ul>";
                foreach($search_result_A as $x){
                    echo "<li><a href='/?pageA={$x}'>{$x}</a></li>";
                }
            echo "</ul></section>";

        } else if(!isset($_GET['pageA']) && !isset($_GET['pageS'])){  //특정 페이지로의 접근이 없는 경우 모든 문서 목록 불러옴.
            define("CHECK_MAINPAGE", true);
            include_once "page_list.php";  //모든 문서 목록.
            
        } else {  //특정 문서로 접근한 경우. (page 변수로 GET 요청이 있는 경우.)
            if(isset($_GET['pageA'])){
                include_once './algorithm/'.$_GET['pageA'].'.php';
            } else {
                include_once './syntax/'.$_GET['pageS'].'.php';
            }
        }
        ?>
    </main>
    <footer></footer>
</body>
</html>